# The Solopreneur Pro Pack

Six ready-to-import n8n automations that run the busywork of a one-person business — so you run like a whole team. These are the done-for-you versions: import the file, fill in a short config block, plug in your accounts, and go.

You own these. They run on n8n (free, self-hosted or cloud). No per-task fees, no subscription just to keep them alive.

---

## What's inside

| # | Automation | What it does |
|---|-----------|--------------|
| 01 | **Missed Call Text-Back** | Texts back every missed call in seconds, handles the reply with AI, emails you the lead. |
| 02 | **New Lead Auto Follow-Up** | Drafts a personal first reply in your voice the moment a lead comes in. Draft-to-you or auto-send. |
| 03 | **Content Multiplier** | Turn one idea into a week of platform-ready posts (hooks, captions, hashtags) in your inbox. |
| 04 | **Client Onboarding Autopilot** | On payment/signup, sends the welcome + intake form + booking link and notifies you. |
| 05 | **Morning Business Digest** | One calm email each morning: yesterday's revenue, new customers, today's focus. Pulled from Stripe. |
| 06 | **Invoice & Payment Recovery** *(bonus)* | Daily scan of open/overdue invoices → one prioritized recovery list. Optional auto-remind. |

---

## Before you start — what you'll need

- **n8n** — free and open-source. Self-host it, or use n8n Cloud's trial. (https://n8n.io)
- **An email credential in n8n** — SMTP or Gmail. Every automation emails you (or a client); attach your credential to the Email nodes once.
- **An OpenAI API key** — used by 01, 02, 03, 05 for the AI parts. (https://platform.openai.com) A few cents per run.
- **Only if you use that automation:**
  - 01 → a Twilio account + number (for calls/SMS)
  - 05 & 06 → a Stripe **restricted** (read-only) key

You don't need all of them — set up only the automations you want.

---

## How to import a workflow (30 seconds)

1. Open n8n → top-right menu (**⋯**) → **Import from File**.
2. Pick one of the `.json` files from the `workflows/` folder.
3. The workflow opens with a **Setup** sticky note explaining that specific one.
4. Open each **Code** node and edit the `CONFIG` block at the very top.
5. Click each **Email** node and select your SMTP/Gmail credential.
6. Toggle the workflow **Active** (top-right). Done.

Repeat for each automation you want. That's the whole job.

---

## Per-automation quick setup

**01 · Missed Call Text-Back**
Fill the CONFIG in both Code nodes (business name, your cell, Twilio SID/token/number, booking link, OpenAI key). In Twilio, point your number's call-status/fallback webhook at `/webhook/missed-call` and the messaging webhook at `/webhook/missed-call-reply`. Test: call the number, don't answer, watch the text arrive.

**02 · New Lead Auto Follow-Up**
Point your form / inbound email / Zapier at `/webhook/new-lead` sending `{ name, email, message, source }`. Set `SEND_MODE` to `draft` (emails you the reply) or `auto` (sends straight to the lead). Edit your name, business, and voice in CONFIG.

**03 · Content Multiplier**
Edit your niche, voice, and platform list in CONFIG. Trigger by POSTing `{ "idea": "..." }` to `/webhook/content-idea`. A full week of posts lands in your inbox.

**04 · Client Onboarding Autopilot**
POST `{ name, email, plan }` to `/webhook/new-client` from your checkout or signup. Set your intake-form URL and booking link in CONFIG. Also accepts a Stripe `checkout.session.completed` payload directly.

**05 · Morning Business Digest**
Paste a Stripe **restricted read-only** key (Charges + Customers) and your OpenAI key. Set the Schedule node to your wake-up time. One brief each morning.

**06 · Invoice & Payment Recovery**
Paste a Stripe restricted key. Leave `AUTO_REMIND` off for a few days to watch the list, then turn it on to let Stripe re-send overdue invoices automatically.

---

## n8n house rules baked in (so they just work)

- All HTTP calls use `this.helpers.httpRequest` (the n8n-safe method).
- Email nodes use the `text`/`html` params with `appendAttribution: false`.
- No secrets are stored in the files — you paste your own keys into the CONFIG blocks.
- Pure-JS base64 helpers (the n8n sandbox blocks `Buffer`).

---

## Questions

Email **contact@stromation.com**. New automations drop for subscribers regularly — grab the free Starter Pack at **stromation.com** to stay on the list.

*Stromation — AI automation studio for solopreneurs. Build a business that runs itself.*
